﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Lib
{
    public partial class UserManagement : System.Web.UI.Page
    {
        string connection = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            displayUserData();
        }

        protected void GetUserDetails_Click(object sender, EventArgs e)
        {
            getUserDetails();
        }

        protected void AddUser_Click(object sender, EventArgs e)
        {
            addUser();
            displayUserData();

        }

        protected void UpdateUser_Click(object sender, EventArgs e)
        {
            updateUser();

            displayUserData();
        }

        protected void DeleteUser_Click(object sender, EventArgs e)
        {
            deleteUser();
            displayUserData();
        }
        void displayUserData()
        {
            SqlConnection con = new SqlConnection(connection);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();

            }

            SqlCommand cmd = new SqlCommand("procUsersList", con);
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            grdUserList.DataSource = dt;
            grdUserList.DataBind();

        }

        void getUserDetails()
        {
            SqlConnection con = new SqlConnection(connection);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("procUserDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p = new SqlParameter("@UserID", txtUserID.Text.Trim());
            cmd.Parameters.Add(p);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            txtFullName.Text = dt.Rows[0]["FullName"].ToString();
            txtDateOfBirth.Text = Convert.ToDateTime(dt.Rows[0]["DateOfBirth"]).ToString("yyyy-MM-dd");
            txtMobileNumber.Text = dt.Rows[0]["MobileNumber"].ToString();
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
            txtAddress.Text = dt.Rows[0]["Address"].ToString();
            txtUserName.Text = dt.Rows[0]["UserName"].ToString();
            txtPassword.Text = dt.Rows[0]["Password"].ToString();
        }

        void addUser()
        {
            SqlConnection con = new SqlConnection(connection);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("procAddUser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FullName", txtFullName.Text.Trim());
            cmd.Parameters.AddWithValue("@DateOfBirth", txtDateOfBirth.Text.Trim());
            cmd.Parameters.AddWithValue("@MobileNumber", txtMobileNumber.Text.Trim());
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
            cmd.Parameters.AddWithValue("@UserName", txtUserName.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('User Added Successfully...!!!!');</script>");
        }

        void updateUser()
        {
            SqlConnection con = new SqlConnection(connection);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("procUpdateUserDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p = new SqlParameter("@UserID", txtUserID.Text.Trim());
            cmd.Parameters.Add(p);
            cmd.Parameters.AddWithValue("@FullName", txtFullName.Text.Trim());
            cmd.Parameters.AddWithValue("@DateOfBirth", txtDateOfBirth.Text.Trim());
            cmd.Parameters.AddWithValue("@MobileNumber", txtMobileNumber.Text.Trim());
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
            cmd.Parameters.AddWithValue("@UserName", txtUserName.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('User Details Updated Successfully...!!!');</script>");
            getUserDetails();
        }

        void deleteUser()
        {
            SqlConnection con = new SqlConnection(connection);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("procDeleteUser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p = new SqlParameter("@UserID", txtUserID.Text.Trim());
            cmd.Parameters.Add(p);
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('User Deleted Successfully');</script>");
            con.Close();
            grdUserList.DataBind();
        }
    }
}